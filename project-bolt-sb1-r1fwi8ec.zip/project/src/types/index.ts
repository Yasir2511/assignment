export type UserRole = 'manager' | 'pantry_staff' | 'delivery_staff';
export type MealType = 'morning' | 'evening' | 'night';
export type DeliveryStatus = 'pending' | 'preparing' | 'ready' | 'delivering' | 'delivered';

export interface Profile {
  id: string;
  user_id: string;
  role: UserRole;
  full_name: string;
  contact_number?: string;
  created_at: string;
  updated_at: string;
}

export interface Patient {
  id: string;
  name: string;
  diseases: string[];
  allergies: string[];
  room_number: string;
  bed_number: string;
  floor_number: number;
  age: number;
  gender: string;
  contact_info?: string;
  emergency_contact?: string;
  created_at: string;
  updated_at: string;
}

export interface DietChart {
  id: string;
  patient_id: string;
  meal_type: MealType;
  ingredients: string[];
  instructions: string[];
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface MealDelivery {
  id: string;
  diet_chart_id: string;
  assigned_to?: string;
  status: DeliveryStatus;
  delivery_notes?: string;
  delivered_at?: string;
  created_at: string;
  updated_at: string;
}