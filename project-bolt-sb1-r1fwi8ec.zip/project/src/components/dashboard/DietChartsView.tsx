import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getPatients, getDietCharts, createDietChart } from '../../lib/api';
import type { Patient, UserRole, MealType } from '../../types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import { Button } from '../ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useToast } from '../ui/use-toast';

interface Props {
  userRole: UserRole;
}

export default function DietChartsView({ userRole }: Props) {
  const { toast } = useToast();
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null);
  const [isAddingDietChart, setIsAddingDietChart] = useState(false);
  const [newDietChart, setNewDietChart] = useState({
    patient_id: '',
    meal_type: 'morning' as MealType,
    ingredients: [],
    instructions: [],
  });

  const { data: patients } = useQuery({
    queryKey: ['patients'],
    queryFn: getPatients,
  });

  const { data: dietCharts, isLoading, refetch } = useQuery({
    queryKey: ['dietCharts', selectedPatient],
    queryFn: () => selectedPatient ? getDietCharts(selectedPatient) : null,
    enabled: !!selectedPatient,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      await createDietChart({
        ...newDietChart,
        created_by: user.id,
      });
      setIsAddingDietChart(false);
      refetch();
      toast({
        title: 'Success',
        description: 'Diet chart added successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add diet chart',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Diet Charts</h2>
        <div className="flex gap-4">
          <Select value={selectedPatient || ''} onValueChange={setSelectedPatient}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select Patient" />
            </SelectTrigger>
            <SelectContent>
              {patients?.map((patient: Patient) => (
                <SelectItem key={patient.id} value={patient.id}>
                  {patient.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {userRole === 'manager' && selectedPatient && (
            <Dialog open={isAddingDietChart} onOpenChange={setIsAddingDietChart}>
              <DialogTrigger asChild>
                <Button>Add Diet Chart</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Diet Chart</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="meal_type">Meal Type</Label>
                      <Select
                        value={newDietChart.meal_type}
                        onValueChange={(value: MealType) =>
                          setNewDietChart({ ...newDietChart, meal_type: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select meal type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="morning">Morning</SelectItem>
                          <SelectItem value="evening">Evening</SelectItem>
                          <SelectItem value="night">Night</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ingredients">Ingredients (comma-separated)</Label>
                      <Input
                        id="ingredients"
                        value={newDietChart.ingredients.join(', ')}
                        onChange={(e) =>
                          setNewDietChart({
                            ...newDietChart,
                            ingredients: e.target.value.split(',').map((i) => i.trim()),
                          })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="instructions">Instructions (comma-separated)</Label>
                      <Input
                        id="instructions"
                        value={newDietChart.instructions.join(', ')}
                        onChange={(e) =>
                          setNewDietChart({
                            ...newDietChart,
                            instructions: e.target.value.split(',').map((i) => i.trim()),
                          })
                        }
                        required
                      />
                    </div>
                  </div>
                  <Button type="submit">Add Diet Chart</Button>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      {selectedPatient && (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Meal Type</TableHead>
              <TableHead>Ingredients</TableHead>
              <TableHead>Instructions</TableHead>
              <TableHead>Created At</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {dietCharts?.map((chart) => (
              <TableRow key={chart.id}>
                <TableCell className="capitalize">{chart.meal_type}</TableCell>
                <TableCell>{chart.ingredients.join(', ')}</TableCell>
                <TableCell>{chart.instructions.join(', ')}</TableCell>
                <TableCell>{new Date(chart.created_at).toLocaleDateString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}