import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getPatients, createPatient } from '../../lib/api';
import type { Patient, UserRole } from '../../types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import { Button } from '../ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useToast } from '../ui/use-toast';

interface Props {
  userRole: UserRole;
}

export default function PatientsView({ userRole }: Props) {
  const { toast } = useToast();
  const [isAddingPatient, setIsAddingPatient] = useState(false);
  const [newPatient, setNewPatient] = useState({
    name: '',
    diseases: [],
    allergies: [],
    room_number: '',
    bed_number: '',
    floor_number: 1,
    age: 0,
    gender: '',
    contact_info: '',
    emergency_contact: '',
  });

  const { data: patients, isLoading, refetch } = useQuery({
    queryKey: ['patients'],
    queryFn: getPatients,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createPatient(newPatient);
      setIsAddingPatient(false);
      refetch();
      toast({
        title: 'Success',
        description: 'Patient added successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add patient',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return <div>Loading patients...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Patients</h2>
        {userRole === 'manager' && (
          <Dialog open={isAddingPatient} onOpenChange={setIsAddingPatient}>
            <DialogTrigger asChild>
              <Button>Add Patient</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Patient</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={newPatient.name}
                      onChange={(e) => setNewPatient({ ...newPatient, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      value={newPatient.age}
                      onChange={(e) => setNewPatient({ ...newPatient, age: parseInt(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender</Label>
                    <Input
                      id="gender"
                      value={newPatient.gender}
                      onChange={(e) => setNewPatient({ ...newPatient, gender: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="room">Room Number</Label>
                    <Input
                      id="room"
                      value={newPatient.room_number}
                      onChange={(e) => setNewPatient({ ...newPatient, room_number: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bed">Bed Number</Label>
                    <Input
                      id="bed"
                      value={newPatient.bed_number}
                      onChange={(e) => setNewPatient({ ...newPatient, bed_number: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="floor">Floor Number</Label>
                    <Input
                      id="floor"
                      type="number"
                      value={newPatient.floor_number}
                      onChange={(e) => setNewPatient({ ...newPatient, floor_number: parseInt(e.target.value) })}
                      required
                    />
                  </div>
                </div>
                <Button type="submit">Add Patient</Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Room</TableHead>
            <TableHead>Bed</TableHead>
            <TableHead>Floor</TableHead>
            <TableHead>Age</TableHead>
            <TableHead>Gender</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {patients?.map((patient: Patient) => (
            <TableRow key={patient.id}>
              <TableCell>{patient.name}</TableCell>
              <TableCell>{patient.room_number}</TableCell>
              <TableCell>{patient.bed_number}</TableCell>
              <TableCell>{patient.floor_number}</TableCell>
              <TableCell>{patient.age}</TableCell>
              <TableCell>{patient.gender}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}