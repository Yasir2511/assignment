import { useQuery } from '@tanstack/react-query';
import { getMealDeliveries, updateDeliveryStatus, getStaff, assignDelivery } from '../../lib/api';
import type { UserRole } from '../../types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useToast } from '../ui/use-toast';

interface Props {
  userRole: UserRole;
  userId: string;
}

export default function DeliveriesView({ userRole, userId }: Props) {
  const { toast } = useToast();

  const { data: deliveries, isLoading, refetch } = useQuery({
    queryKey: ['deliveries'],
    queryFn: getMealDeliveries,
  });

  const { data: staff } = useQuery({
    queryKey: ['staff'],
    queryFn: getStaff,
    enabled: userRole === 'pantry_staff',
  });

  const handleStatusUpdate = async (id: string, status: string) => {
    try {
      await updateDeliveryStatus(id, status as any);
      refetch();
      toast({
        title: 'Success',
        description: 'Delivery status updated successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update delivery status',
        variant: 'destructive',
      });
    }
  };

  const handleAssignStaff = async (deliveryId: string, staffId: string) => {
    try {
      await assignDelivery(deliveryId, staffId);
      refetch();
      toast({
        title: 'Success',
        description: 'Delivery assigned successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to assign delivery',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return <div>Loading deliveries...</div>;
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Deliveries</h2>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Patient</TableHead>
            <TableHead>Room</TableHead>
            <TableHead>Meal Type</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {deliveries?.map((delivery) => (
            <TableRow key={delivery.id}>
              <TableCell>{delivery.diet_charts.patients.name}</TableCell>
              <TableCell>{delivery.diet_charts.patients.room_number}</TableCell>
              <TableCell className="capitalize">{delivery.diet_charts.meal_type}</TableCell>
              <TableCell className="capitalize">{delivery.status}</TableCell>
              <TableCell>
                {userRole === 'pantry_staff' && delivery.status === 'pending' && (
                  <Select
                    onValueChange={(staffId) => handleAssignStaff(delivery.id, staffId)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Assign staff" />
                    </SelectTrigger>
                    <SelectContent>
                      {staff?.map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.full_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
                {userRole === 'delivery_staff' && delivery.assigned_to === userId && (
                  <div className="flex gap-2">
                    {delivery.status === 'ready' && (
                      <Button
                        onClick={() => handleStatusUpdate(delivery.id, 'delivering')}
                      >
                        Start Delivery
                      </Button>
                    )}
                    {delivery.status === 'delivering' && (
                      <Button
                        onClick={() => handleStatusUpdate(delivery.id, 'delivered')}
                      >
                        Mark Delivered
                      </Button>
                    )}
                  </div>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}