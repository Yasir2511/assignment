import { useEffect, useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { getProfile } from '../lib/api';
import type { Profile } from '../types';
import PatientsView from '../components/dashboard/PatientsView';
import DietChartsView from '../components/dashboard/DietChartsView';
import DeliveriesView from '../components/dashboard/DeliveriesView';

export default function Dashboard() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadProfile() {
      try {
        const data = await getProfile();
        setProfile(data);
      } catch (error) {
        console.error('Error loading profile:', error);
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, []);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!profile) {
    return <div>Error loading profile</div>;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-gray-900">
              Hospital Food Management
            </h1>
            <div className="text-sm text-gray-500">
              Welcome, {profile.full_name} ({profile.role})
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <Tabs defaultValue="patients" className="space-y-4">
          <TabsList>
            <TabsTrigger value="patients">Patients</TabsTrigger>
            <TabsTrigger value="diet-charts">Diet Charts</TabsTrigger>
            <TabsTrigger value="deliveries">Deliveries</TabsTrigger>
          </TabsList>

          <TabsContent value="patients">
            <PatientsView userRole={profile.role} />
          </TabsContent>

          <TabsContent value="diet-charts">
            <DietChartsView userRole={profile.role} />
          </TabsContent>

          <TabsContent value="deliveries">
            <DeliveriesView userRole={profile.role} userId={profile.id} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}