import { supabase } from './supabase';
import type { Patient, DietChart, MealDelivery, Profile } from '../types';

// Profile API
export async function getProfile() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('user_id', user.id)
    .single();

  return data;
}

// Patients API
export async function getPatients() {
  const { data } = await supabase
    .from('patients')
    .select('*')
    .order('created_at', { ascending: false });
  return data;
}

export async function createPatient(patient: Omit<Patient, 'id' | 'created_at' | 'updated_at'>) {
  const { data, error } = await supabase
    .from('patients')
    .insert(patient)
    .select()
    .single();

  if (error) throw error;
  return data;
}

// Diet Charts API
export async function getDietCharts(patientId: string) {
  const { data } = await supabase
    .from('diet_charts')
    .select('*')
    .eq('patient_id', patientId)
    .order('created_at', { ascending: false });
  return data;
}

export async function createDietChart(dietChart: Omit<DietChart, 'id' | 'created_at' | 'updated_at'>) {
  const { data, error } = await supabase
    .from('diet_charts')
    .insert(dietChart)
    .select()
    .single();

  if (error) throw error;
  return data;
}

// Meal Deliveries API
export async function getMealDeliveries() {
  const { data } = await supabase
    .from('meal_deliveries')
    .select(`
      *,
      diet_charts (
        *,
        patients (*)
      )
    `)
    .order('created_at', { ascending: false });
  return data;
}

export async function updateDeliveryStatus(
  id: string,
  status: MealDelivery['status'],
  notes?: string
) {
  const { data, error } = await supabase
    .from('meal_deliveries')
    .update({
      status,
      delivery_notes: notes,
      ...(status === 'delivered' ? { delivered_at: new Date().toISOString() } : {})
    })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

// Staff API
export async function getStaff() {
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });
  return data;
}

export async function assignDelivery(deliveryId: string, staffId: string) {
  const { data, error } = await supabase
    .from('meal_deliveries')
    .update({ assigned_to: staffId })
    .eq('id', deliveryId)
    .select()
    .single();

  if (error) throw error;
  return data;
}