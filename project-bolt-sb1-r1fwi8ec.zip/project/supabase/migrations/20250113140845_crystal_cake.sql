/*
  # Initial Schema Setup for Hospital Food Management System

  1. Tables Created
    - profiles
      - id (uuid, primary key)
      - user_id (uuid, references auth.users)
      - role (enum: manager, pantry_staff, delivery_staff)
      - full_name (text)
      - contact_number (text)
      - created_at (timestamp)
      - updated_at (timestamp)
    
    - patients
      - id (uuid, primary key)
      - name (text)
      - diseases (text[])
      - allergies (text[])
      - room_number (text)
      - bed_number (text)
      - floor_number (integer)
      - age (integer)
      - gender (text)
      - contact_info (text)
      - emergency_contact (text)
      - created_at (timestamp)
      - updated_at (timestamp)
    
    - diet_charts
      - id (uuid, primary key)
      - patient_id (uuid, references patients)
      - meal_type (enum: morning, evening, night)
      - ingredients (text[])
      - instructions (text[])
      - created_by (uuid, references profiles)
      - created_at (timestamp)
      - updated_at (timestamp)
    
    - meal_deliveries
      - id (uuid, primary key)
      - diet_chart_id (uuid, references diet_charts)
      - assigned_to (uuid, references profiles)
      - status (enum: pending, preparing, ready, delivering, delivered)
      - delivery_notes (text)
      - delivered_at (timestamp)
      - created_at (timestamp)
      - updated_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for each role
*/

-- Create custom types
CREATE TYPE user_role AS ENUM ('manager', 'pantry_staff', 'delivery_staff');
CREATE TYPE meal_type AS ENUM ('morning', 'evening', 'night');
CREATE TYPE delivery_status AS ENUM ('pending', 'preparing', 'ready', 'delivering', 'delivered');

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  role user_role NOT NULL,
  full_name text NOT NULL,
  contact_number text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create patients table
CREATE TABLE patients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  diseases text[] DEFAULT '{}',
  allergies text[] DEFAULT '{}',
  room_number text NOT NULL,
  bed_number text NOT NULL,
  floor_number integer NOT NULL,
  age integer NOT NULL,
  gender text NOT NULL,
  contact_info text,
  emergency_contact text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create diet_charts table
CREATE TABLE diet_charts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid REFERENCES patients NOT NULL,
  meal_type meal_type NOT NULL,
  ingredients text[] DEFAULT '{}',
  instructions text[] DEFAULT '{}',
  created_by uuid REFERENCES profiles NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create meal_deliveries table
CREATE TABLE meal_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  diet_chart_id uuid REFERENCES diet_charts NOT NULL,
  assigned_to uuid REFERENCES profiles,
  status delivery_status DEFAULT 'pending',
  delivery_notes text,
  delivered_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE diet_charts ENABLE ROW LEVEL SECURITY;
ALTER TABLE meal_deliveries ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Profiles are viewable by authenticated users"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Profiles can be created by authenticated users"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create policies for patients
CREATE POLICY "Patients are viewable by authenticated users"
  ON patients FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Managers can create patients"
  ON patients FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE user_id = auth.uid()
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can update patients"
  ON patients FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE user_id = auth.uid()
      AND role = 'manager'
    )
  );

-- Create policies for diet_charts
CREATE POLICY "Diet charts are viewable by authenticated users"
  ON diet_charts FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Managers can create diet charts"
  ON diet_charts FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE user_id = auth.uid()
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can update diet charts"
  ON diet_charts FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE user_id = auth.uid()
      AND role = 'manager'
    )
  );

-- Create policies for meal_deliveries
CREATE POLICY "Meal deliveries are viewable by authenticated users"
  ON meal_deliveries FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Staff can update assigned deliveries"
  ON meal_deliveries FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE user_id = auth.uid()
      AND (role = 'pantry_staff' OR role = 'delivery_staff')
    )
  );

-- Create function to handle profile updates
CREATE OR REPLACE FUNCTION handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
CREATE TRIGGER set_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();

CREATE TRIGGER set_patients_updated_at
  BEFORE UPDATE ON patients
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();

CREATE TRIGGER set_diet_charts_updated_at
  BEFORE UPDATE ON diet_charts
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();

CREATE TRIGGER set_meal_deliveries_updated_at
  BEFORE UPDATE ON meal_deliveries
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();